export class User {
    name: string;
    location: string;
    job: string;
}
