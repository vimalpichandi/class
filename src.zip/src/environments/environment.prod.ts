export const environment = {
  production: true,
  api_url: 'https://recoverycoach4u.com/rc',  
  img_url: 'http://000.000.0.000:0000/xxx',
  dateFormat:'MM/DD/YYYY',
};
