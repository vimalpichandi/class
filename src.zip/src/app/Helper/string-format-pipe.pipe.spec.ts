import { StringFormatPipePipe } from './string-format-pipe.pipe';

describe('StringFormatPipePipe', () => {
  it('create an instance', () => {
    const pipe = new StringFormatPipePipe();
    expect(pipe).toBeTruthy();
  });
});
