import { OnlyAlphanumericDirective } from './only-alphanumeric.directive';

describe('OnlyAlphanumericDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyAlphanumericDirective();
    expect(directive).toBeTruthy();
  });
});
