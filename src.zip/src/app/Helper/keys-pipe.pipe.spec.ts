import { KeysPipePipe } from './keys-pipe.pipe';

describe('KeysPipePipe', () => {
  it('create an instance', () => {
    const pipe = new KeysPipePipe();
    expect(pipe).toBeTruthy();
  });
});
