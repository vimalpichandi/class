export class User { 
item: {
	token: string;
	userId: number;
};
}
  