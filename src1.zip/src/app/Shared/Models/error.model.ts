export class Errors {
    error: string;
    message: string;
  }
  