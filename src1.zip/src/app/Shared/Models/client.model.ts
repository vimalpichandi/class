export class Client {
    //error: string;
   // message: string;
  }
  