import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { UserService } from '../../../../Shared/Services/user.service'; 

@Component({
  selector: 'app-adminlist',
  templateUrl: './adminlist.component.html',
  styleUrls: ['./adminlist.component.scss']
})
export class AdminlistComponent implements OnInit {

   constructor(private userService: UserService) { }

  ngOnInit() { 
    this.getUserAllData();
    this.fetchCountryCode(); }

    gitUserlList:any;

    getUserAllData(){
        this.userService.getUserAllData().subscribe(
          data => {
            this.gitUserlList = data;
    
            console.log("gitUserlList", data)
    
          },
          (err: HttpErrorResponse) => {
            console.log(err.message);
          }
    
        );
     
    }
/*
  profilepage.component.ts  
				   *fetchCountryCode */
 counrtyCodeList:any;
 countrycode:any=1;
 fetchCountryCode(){
  // alert("fetchCountryCode -admn");
  //  this.userService.fetchCountryCode().subscribe(
  //    data => {
  //    this.counrtyCodeList = data;
  //   // console.log("counrtyCodeList -admin : ", data )
  //    })
     
 } 

 

}
