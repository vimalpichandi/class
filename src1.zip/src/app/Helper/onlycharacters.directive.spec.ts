import { OnlycharactersDirective } from './onlycharacters.directive';

describe('OnlycharactersDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlycharactersDirective();
    expect(directive).toBeTruthy();
  });
});
